Cat and Dog Classifier using Data Science Techniques

## Dataset
you can find the dataset using the API command : kaggle datasets download -d tongpython/cat-and-dog

## Libraries imported
1.numpy 
2.cv2
3.os
4.random
5.matplotlib
6.pickle

Thankyou for reviewing my submission!
